import React from 'react'
import './contact.css'

export default function contact() {
  return (
    <div>
      <section id="contact" className='pt-5'>
        <div className='container'> 
          <h2>Stay Connected</h2>
          <p className="mb-0">
                  <small>Gurugaon,Haryana,India</small>
              </p>
              <a href="mailto:sk1858654@gmail.com" className="m-0 text-white" style={{fontSize:20}}>
                  <strong>sk1858654@gmail.com</strong>
              </a>
              <p>(+91)8529767578</p>
              <div className="nav-icon py-3">
                  <a href="https://www.linkedin.com/in/sabir-khan-81028422bhttps://www.linkedin.com/in/sabir-khan-81028422b" target="_blank" rel="noreferrer" className="text-white w-5 p-2">
                      <i className="fab fa-linkedin"></i></a>
                  <a href="https://www.facebook.com/profile.php?id=100036303540370" target="_blank" rel="noreferrer" className="text-white w-3 p-2">
                      <i className="fab fa-facebook"></i></a>
                  <a href="https://instagram.com/___sabir_sarpanch___?igshid=MjEwN2IyYWYwYw==" target="_blank" rel="noreferrer" className="text-white w-5 p-2">
                      <i className="fab fa-instagram"></i></a>
                  <a href="https://github.com/Sabir1507" target="_blank" rel="noreferrer" className="text-white w-5 p-2">
                      <i className="fab fa-github"></i></a>
              </div>
        </div>
      </section>
    </div>
  )
}
